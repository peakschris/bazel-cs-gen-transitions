int afunction() {
    return 3;
}
