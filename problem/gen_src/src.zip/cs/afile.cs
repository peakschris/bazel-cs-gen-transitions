public class A
{
    public static int AFunction()
    {
        return 3;
    }
}
